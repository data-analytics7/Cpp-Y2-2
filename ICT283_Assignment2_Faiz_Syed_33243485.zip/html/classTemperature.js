var classTemperature =
[
    [ "Temperature", "classTemperature.html#ab8f4f9e793a8e4f35eed33c240bbe278", null ],
    [ "GetTemp", "classTemperature.html#aa462625b0a121825fdaf9aaafcbea476", null ],
    [ "operator >", "classTemperature.html#ae95e592bfc53e7fe6b9cadb80c89bc0d", null ],
    [ "operator<", "classTemperature.html#aad32562ba9dbebfb966dc463395df0b3", null ],
    [ "SetTemp", "classTemperature.html#ab70c4c5632cc1b915cb8b31021098eb5", null ],
    [ "temperature", "classTemperature.html#aee3841a95c52988c556a7f7e8ef8fe8c", null ]
];