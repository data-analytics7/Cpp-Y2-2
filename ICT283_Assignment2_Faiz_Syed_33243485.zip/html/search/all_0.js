var searchData=
[
  ['avgambairtemp',['avgAmbAirTemp',['../classProcess.html#a1e58951b4e99957d806767cbe95bde6c',1,'Process']]],
  ['avgwindspeed',['avgWindSpeed',['../classProcess.html#a323529bd2042640241d3effdaaf09d57',1,'Process']]]
];
