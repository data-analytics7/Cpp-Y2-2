var searchData=
[
  ['windlogmap',['windLogMap',['../classProcess.html#a1427a267519b4b6e9c7c020cf76624da',1,'Process']]],
  ['windlogvec',['windLogVec',['../classCallback.html#af06b50f5e1081db40de866e304b14ed3',1,'Callback']]]
];
