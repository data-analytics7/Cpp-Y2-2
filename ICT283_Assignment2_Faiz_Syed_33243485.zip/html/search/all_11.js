var searchData=
[
  ['year',['year',['../classDate.html#a68742ab0fdabd6dbadb5c0fdb7888f55',1,'Date']]]
];
