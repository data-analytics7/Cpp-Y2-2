var searchData=
[
  ['solar',['solar',['../classWindLogType.html#ac6a02067035e3266731b9512a62ac7f9',1,'WindLogType']]],
  ['speed',['speed',['../classWindLogType.html#a0ade1e98e89dbe503265fedd0001fac0',1,'WindLogType']]]
];
