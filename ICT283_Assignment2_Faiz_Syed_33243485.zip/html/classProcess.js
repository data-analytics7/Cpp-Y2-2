var classProcess =
[
    [ "Process", "classProcess.html#a9f4553eac74c657bb451f390c17d6bea", null ],
    [ "GetAvgAmbAirTemp", "classProcess.html#a48f8594801a8e0ea8eeafac80df56252", null ],
    [ "GetAvgWindSpeed", "classProcess.html#a88293e6b06f025f9d423b93e7edc3021", null ],
    [ "GetHighSolarRad", "classProcess.html#ae72f91f387154cac7498b3f6d7541253", null ],
    [ "GetTotSolarRad", "classProcess.html#a3af15e7dd35980d7d344a7d1997d3d2c", null ],
    [ "GetWindLog", "classProcess.html#a438535bf5e5b309606cbcfeb865ec3a7", null ],
    [ "mapKeyExists", "classProcess.html#a3553e1a094d901d30b1e84a0571e7dec", null ],
    [ "mapKeyExists", "classProcess.html#a55fa3f146deca4ff6e8ce5f2e875935c", null ],
    [ "SetAvgAmbAirTemp", "classProcess.html#a339e32427f20f3fb6440755c2a393ffe", null ],
    [ "SetAvgWindSpeed", "classProcess.html#a162886d0d75b56b91da9ee863f54d345", null ],
    [ "SetTotSolarRad", "classProcess.html#adcb7532e60bbe48883f88a3706266c19", null ],
    [ "SetWindLog", "classProcess.html#a28370be4a295d26f4fef555cfc88650b", null ],
    [ "avgAmbAirTemp", "classProcess.html#a1e58951b4e99957d806767cbe95bde6c", null ],
    [ "avgWindSpeed", "classProcess.html#a323529bd2042640241d3effdaaf09d57", null ],
    [ "totSolarRad", "classProcess.html#aadb6891516611b74c4a55f2c8bf96119", null ],
    [ "windLogMap", "classProcess.html#a1427a267519b4b6e9c7c020cf76624da", null ]
];