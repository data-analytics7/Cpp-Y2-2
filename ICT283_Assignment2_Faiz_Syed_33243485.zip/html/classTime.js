var classTime =
[
    [ "Time", "classTime.html#a4245e409c7347d1d671858962c2ca3b5", null ],
    [ "Time", "classTime.html#ab2532ffd4eacc458882152d920a532ca", null ],
    [ "GetHour", "classTime.html#a468cb29f77bc1b290df3e63a87164c30", null ],
    [ "GetMinute", "classTime.html#a5e9c43cb59f31cf7e0b8b1df79227e09", null ],
    [ "operator >", "classTime.html#a04bf0ff43c120e752d945280712b2218", null ],
    [ "operator<", "classTime.html#a1898fa143a795aa321e2bdaac00f7702", null ],
    [ "operator==", "classTime.html#aa170cb8619ab81a72063eb466c1bff2c", null ],
    [ "SetHour", "classTime.html#a4be6aa42ad0134696e196790daf901c6", null ],
    [ "SetMinute", "classTime.html#adf222f59b771dd26070379fefe651f62", null ],
    [ "hour", "classTime.html#a35da41d375c6ab00546290a0c813822e", null ],
    [ "minute", "classTime.html#afbb9c9cc5d47750cf0005b03fdf18579", null ]
];