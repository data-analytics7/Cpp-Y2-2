var dir_d3242f4584e319f9ce292875ede6998f =
[
    [ "Assignment 2- ICT283", "dir_a89f989890e68bb523cf4b382c735cb7.html", "dir_a89f989890e68bb523cf4b382c735cb7" ]
];