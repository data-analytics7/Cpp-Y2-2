var structBSTNode =
[
    [ "element", "structBSTNode.html#a920870962984509fae3d55e614b18f02", null ],
    [ "left", "structBSTNode.html#ad6a6b5db9d642573d5c966d6137af213", null ],
    [ "right", "structBSTNode.html#abdc329dd371a442d747b59bc70c94e15", null ]
];