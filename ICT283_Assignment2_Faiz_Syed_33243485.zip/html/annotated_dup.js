var annotated_dup =
[
    [ "BST", "classBST.html", "classBST" ],
    [ "BSTNode", "structBSTNode.html", "structBSTNode" ],
    [ "Callback", "classCallback.html", "classCallback" ],
    [ "Date", "classDate.html", "classDate" ],
    [ "Process", "classProcess.html", "classProcess" ],
    [ "Temperature", "classTemperature.html", "classTemperature" ],
    [ "Time", "classTime.html", "classTime" ],
    [ "WindLogType", "classWindLogType.html", "classWindLogType" ]
];