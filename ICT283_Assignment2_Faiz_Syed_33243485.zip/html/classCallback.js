var classCallback =
[
    [ "funcPntr", "classCallback.html#a160906d2bc24db2859e4c9ccc0246ea7", null ],
    [ "windLogVec", "classCallback.html#af06b50f5e1081db40de866e304b14ed3", null ]
];