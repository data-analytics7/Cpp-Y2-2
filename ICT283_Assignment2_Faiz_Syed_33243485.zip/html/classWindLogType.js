var classWindLogType =
[
    [ "WindLogType", "classWindLogType.html#a66ec93cd069c686f1a45e3fcd3c41769", null ],
    [ "GetAmbAirTemp", "classWindLogType.html#ae7f67e17335a8219ca2dd1d955051857", null ],
    [ "GetDate", "classWindLogType.html#a0c839127d287a6fc325266b0d56bdac5", null ],
    [ "GetSolarRad", "classWindLogType.html#a595fd82d06223f728a21736b514e31d0", null ],
    [ "GetTime", "classWindLogType.html#aba8f636594b8a9a49b842745a99482db", null ],
    [ "GetWindSpeed", "classWindLogType.html#a00b3014bf69a4ec5acc6d78a17eab84c", null ],
    [ "operator >", "classWindLogType.html#ac9f2dd736d3e739355467ca0a6b9107d", null ],
    [ "operator<", "classWindLogType.html#a27ecd9550102a44572c237b0a5a857d1", null ],
    [ "operator==", "classWindLogType.html#a4f9ec57f10e546b5bf7e299b9be44a6f", null ],
    [ "SetAmbAirTemp", "classWindLogType.html#a567373179afb704c0d4c51d645511016", null ],
    [ "SetDate", "classWindLogType.html#a82e93a2314e16c7dfd62128baed6263d", null ],
    [ "SetSolarRad", "classWindLogType.html#a80ebe19b8e45f2eb5542e629fb9b6102", null ],
    [ "SetTime", "classWindLogType.html#a9438899d82fd11b30e583255d63b3603", null ],
    [ "SetWindSpeed", "classWindLogType.html#a46519d6c86757f2c420068f7b8fc0eff", null ],
    [ "d", "classWindLogType.html#ac0a6973025fadd995b5df4216ea099df", null ],
    [ "solar", "classWindLogType.html#ac6a02067035e3266731b9512a62ac7f9", null ],
    [ "speed", "classWindLogType.html#a0ade1e98e89dbe503265fedd0001fac0", null ],
    [ "t", "classWindLogType.html#a04c6280723158507d91e80dc9b378608", null ],
    [ "temp", "classWindLogType.html#a3221a6f08b659b897a1d1a2ba4bd7e25", null ],
    [ "tm", "classWindLogType.html#a857887e223e31c06e6a0ce3feba343bf", null ]
];